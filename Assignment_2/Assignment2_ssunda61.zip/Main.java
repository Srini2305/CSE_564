import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        SolutionGUI solutionGUI = new SolutionGUI();
        solutionGUI.setVisible(true);
        solutionGUI.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}
